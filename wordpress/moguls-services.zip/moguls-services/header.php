<?php
/**
 * Site header: loading screen and top menu. Built from the static site by wordpress/build.py.
 */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div class="loader" id="loader" role="status" aria-label="Loading">
  <div class="loader-inner">
    <svg class="crane" viewBox="0 0 480 320" aria-hidden="true">
      <defs>
        <linearGradient id="ldWall" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stop-color="#f0ebd6"/><stop offset="1" stop-color="#fcf9ea"/>
        </linearGradient>
        <linearGradient id="ldFloor" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stop-color="#e5ddbb"/><stop offset="1" stop-color="#f1ecd9"/>
        </linearGradient>
        <linearGradient id="ldGirder" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stop-color="#d5ae58"/><stop offset=".45" stop-color="#b8892d"/><stop offset="1" stop-color="#785c1e"/>
        </linearGradient>
        <linearGradient id="ldSteel" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stop-color="#0b1630"/><stop offset=".35" stop-color="#39486e"/><stop offset=".6" stop-color="#1b2a51"/><stop offset="1" stop-color="#0b1630"/>
        </linearGradient>
        <linearGradient id="ldBody" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stop-color="#3a4a72"/><stop offset="1" stop-color="#111b34"/>
        </linearGradient>
        <linearGradient id="ldDrum" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stop-color="#909ab5"/><stop offset=".5" stop-color="#d3d7e1"/><stop offset="1" stop-color="#4f6398"/>
        </linearGradient>
        <linearGradient id="ldRope" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stop-color="#15213f"/><stop offset=".5" stop-color="#7c88a7"/><stop offset="1" stop-color="#15213f"/>
        </linearGradient>
        <linearGradient id="ldKraft" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stop-color="#d1b16c"/><stop offset="1" stop-color="#b99953"/>
        </linearGradient>
        <linearGradient id="ldWood" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stop-color="#d9c59a"/><stop offset="1" stop-color="#b39e70"/>
        </linearGradient>
        <pattern id="ldHazard" width="8" height="8" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
          <rect width="8" height="8" fill="#0d1c42"/><rect width="4" height="8" fill="#b58a2d"/>
        </pattern>
        <pattern id="ldLane" width="12" height="6" patternUnits="userSpaceOnUse" patternTransform="skewX(-40)">
          <rect width="12" height="6" fill="#f1ecd9"/><rect width="6" height="6" fill="#b8892d"/>
        </pattern>
        <filter id="ldBlur" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="2.5"/></filter>

        <!-- carton, 66 wide by 48 tall, front face starts at y 8 -->
        <g id="ldCarton">
          <polygon points="0,8 10,0 66,0 56,8" fill="#e0c385"/>
          <polygon points="56,8 66,0 66,40 56,48" fill="#a38545"/>
          <rect x="0" y="8" width="56" height="40" fill="url(#ldKraft)"/>
          <polygon points="0,8 10,0 66,0 56,8" fill="none" stroke="#b59755" stroke-width=".6"/>
          <line x1="0" y1="27" x2="56" y2="27" stroke="#a98b4b" stroke-width=".5" opacity=".5"/>
          <polygon points="24,8 34,0 40,0 30,8" fill="#e9d4a7" opacity=".9"/>
          <rect x="24" y="8" width="6" height="12" fill="#e9d4a7" opacity=".9"/>
          <rect x="5" y="30" width="18" height="13" fill="#fdfdfa"/>
          <rect x="5" y="30" width="18" height="3" fill="#b8892d"/>
          <path d="M7 36v5M8.5 36v5M10.5 36v5M11.5 36v5M13.5 36v5M15 36v5M16 36v5M18 36v5M19.5 36v5M21 36v5" stroke="#0d1c42" stroke-width=".7"/>
          <path d="M40 38l4 -4 4 4M44 34v8" stroke="#7d642e" stroke-width="1" fill="none" opacity=".7"/>
        </g>
        <g id="ldPallet">
          <rect x="0" y="0" width="76" height="3" fill="url(#ldWood)"/>
          <rect x="0" y="3" width="6" height="6" fill="#a89263"/>
          <rect x="35" y="3" width="6" height="6" fill="#a89263"/>
          <rect x="70" y="3" width="6" height="6" fill="#a89263"/>
          <rect x="0" y="9" width="76" height="3" fill="#bfaa7c"/>
          <path d="M12 0v3M24 0v3M48 0v3M60 0v3" stroke="#9b865a" stroke-width=".8"/>
        </g>
      </defs>

      <!-- building -->
      <rect width="480" height="282" fill="url(#ldWall)"/>
      <g opacity=".55">
        <g fill="#d5ceb2">
          <rect x="150" y="96" width="5" height="186"/><rect x="236" y="96" width="5" height="186"/><rect x="322" y="96" width="5" height="186"/>
        </g>
        <g fill="#d9b465">
          <rect x="150" y="150" width="177" height="4"/><rect x="150" y="212" width="177" height="4"/>
        </g>
        <g fill="#dcceb0">
          <rect x="162" y="128" width="30" height="22"/><rect x="196" y="134" width="28" height="16"/><rect x="250" y="126" width="34" height="24"/><rect x="290" y="132" width="26" height="18"/>
          <rect x="164" y="190" width="34" height="22"/><rect x="204" y="194" width="24" height="18"/><rect x="254" y="188" width="28" height="24"/>
        </g>
      </g>
      <rect y="281" width="480" height="39" fill="url(#ldFloor)"/>
      <rect y="280" width="480" height="2" fill="#ccc4a1"/>
      <rect x="0" y="300" width="480" height="5" fill="url(#ldLane)" opacity=".8"/>
      <path d="M80 282L56 320M200 282L196 320M320 282L334 320M440 282L470 320" stroke="#cdc5b3" stroke-width="1"/>

      <!-- columns and runway -->
      <g>
        <rect x="24" y="44" width="16" height="238" fill="url(#ldSteel)"/>
        <rect x="440" y="44" width="16" height="238" fill="url(#ldSteel)"/>
        <rect x="18" y="276" width="28" height="6" fill="#15213f"/>
        <rect x="434" y="276" width="28" height="6" fill="#15213f"/>
        <rect x="24" y="250" width="16" height="26" fill="url(#ldHazard)"/>
        <rect x="440" y="250" width="16" height="26" fill="url(#ldHazard)"/>
      </g>
      <!-- end trucks -->
      <rect x="16" y="26" width="34" height="14" rx="2" fill="#182547"/>
      <rect x="430" y="26" width="34" height="14" rx="2" fill="#182547"/>
      <circle cx="24" cy="42" r="4" fill="#081023"/><circle cx="42" cy="42" r="4" fill="#081023"/>
      <circle cx="438" cy="42" r="4" fill="#081023"/><circle cx="456" cy="42" r="4" fill="#081023"/>
      <!-- bridge girder -->
      <rect x="20" y="34" width="440" height="4" fill="#564216"/>
      <rect x="20" y="38" width="440" height="20" fill="url(#ldGirder)"/>
      <rect x="20" y="58" width="440" height="4" fill="#443411"/>
      <g fill="#443411" opacity=".55">
        <circle cx="34" cy="48" r="1.2"/><circle cx="446" cy="48" r="1.2"/>
        <rect x="88" y="38" width="2" height="20"/><rect x="156" y="38" width="2" height="20"/><rect x="224" y="38" width="2" height="20"/><rect x="292" y="38" width="2" height="20"/><rect x="360" y="38" width="2" height="20"/>
      </g>
      <rect x="228" y="42" width="34" height="12" fill="#fdfdfa"/>
      <text x="245" y="51.5" text-anchor="middle" font-family="IBM Plex Mono, monospace" font-size="8" font-weight="600" fill="#0d1c42">5 TON</text>

      <!-- the box waiting to be picked, and the one just delivered -->
      <ellipse cx="110" cy="281" rx="42" ry="4" fill="#000000" opacity=".18" filter="url(#ldBlur)"/>
      <use href="#ldPallet" x="72" y="268"/>
      <use class="ld-pick" href="#ldCarton" x="82" y="220"/>
      <ellipse cx="370" cy="281" rx="42" ry="4" fill="#000000" opacity=".18" filter="url(#ldBlur)"/>
      <use href="#ldPallet" x="332" y="268"/>
      <use class="ld-drop" href="#ldCarton" x="342" y="220"/>

      <!-- trolley, ropes and load: everything that travels along the girder -->
      <g class="ld-x">
        <g transform="translate(110 0)">
          <ellipse class="ld-shadow" cx="0" cy="281" rx="30" ry="3.5" fill="#000000" filter="url(#ldBlur)"/>
          <circle cx="-16" cy="64" r="4" fill="#081023"/><circle cx="16" cy="64" r="4" fill="#081023"/>
          <rect x="-26" y="66" width="52" height="20" rx="2" fill="url(#ldBody)"/>
          <rect x="-34" y="69" width="10" height="13" rx="2" fill="#1e2f59"/>
          <rect x="-12" y="70" width="24" height="12" rx="6" fill="url(#ldDrum)"/>
          <path d="M-8 70v12M-4 70v12M0 70v12M4 70v12M8 70v12" stroke="#455786" stroke-width=".7"/>
          <circle cx="20" cy="71" r="2" fill="#b58a2d"/>
          <g transform="translate(0 86)">
            <g class="ld-rope">
              <rect x="-4" y="0" width="1.6" height="100" fill="url(#ldRope)"/>
              <rect x="2.4" y="0" width="1.6" height="100" fill="url(#ldRope)"/>
            </g>
            <g class="ld-y">
              <g class="ld-sway">
                <rect x="-10" y="0" width="20" height="20" rx="3" fill="url(#ldHazard)"/>
                <circle cx="0" cy="8" r="5" fill="#1e2f59" stroke="#081023" stroke-width="1"/>
                <rect x="-2" y="20" width="4" height="6" fill="#0d1c42"/>
                <path d="M0 26v6a6 6 0 1 1 -6 6" fill="none" stroke="#0d1c42" stroke-width="3.5" stroke-linecap="round"/>
                <g class="ld-carry">
                  <path d="M-1 32L-21 55M1 32L33 52" stroke="#38476e" stroke-width="1.6" stroke-dasharray="3 1.6"/>
                  <use href="#ldCarton" x="-28" y="50"/>
                </g>
              </g>
            </g>
          </g>
        </g>
      </g>
    </svg>
    <img class="loader-logo" src="<?php echo esc_url( mm_mod( 'logo_header' ) ); ?>" alt="" width="1000" height="315">
    <div class="loader-bar"><span></span></div>
  </div>
</div>
<a class="skip" href="#main">Skip to content</a>
<header class="site-header">
  <div class="wrap">
    <a class="brand" href="<?php echo esc_url( mm_url( 'index' ) ); ?>"><img src="<?php echo esc_url( mm_mod( 'logo_header' ) ); ?>" alt="<?php echo esc_attr( mm_setting( 'businessName' ) ); ?>" width="1000" height="315"></a>
    <button class="menu-btn" type="button" aria-expanded="false" aria-controls="nav">Menu</button>
    <nav class="nav" id="nav" aria-label="Main">
      <a href="<?php echo esc_url( mm_url( 'index' ) ); ?>"<?php mm_current( 'index' ); ?>>Home</a>
      <a href="<?php echo esc_url( mm_url( 'services' ) ); ?>"<?php mm_current( 'services' ); ?>>Services and Pricing</a>
      <a href="<?php echo esc_url( mm_url( 'bundles' ) ); ?>"<?php mm_current( 'bundles' ); ?>>Variety Packs</a>
      <a href="<?php echo esc_url( mm_url( 'grocery' ) ); ?>"<?php mm_current( 'grocery' ); ?>>Grocery and CPG</a>
      <a href="<?php echo esc_url( mm_url( 'calculator' ) ); ?>"<?php mm_current( 'calculator' ); ?>>Cost Calculator</a>
      <a href="<?php echo esc_url( mm_url( 'quote' ) ); ?>"<?php mm_current( 'quote' ); ?>>Contact</a>
      <a class="btn orange header-cta" href="<?php echo esc_url( mm_url( 'quote' ) ); ?>">Get a Quote</a>
    </nav>
  </div>
</header>
